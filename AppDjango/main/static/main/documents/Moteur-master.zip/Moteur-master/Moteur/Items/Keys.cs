﻿namespace Moteur.Items
{
    internal class Keys : Item
    {
        public override void OnCatch()
        {
            base.OnCatch();
        }

        public override void OnUse()
        {
            throw new NotImplementedException();
        }
    }
}
