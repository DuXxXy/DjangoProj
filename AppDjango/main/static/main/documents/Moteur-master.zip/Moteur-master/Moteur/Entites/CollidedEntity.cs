﻿namespace Moteur.Entites;

public class CollidedEntity : DecorativeEntity
{
    public CollidedEntity(int x, int y, string ImageFile_nbAnimation_Temp) : base(x, y, ImageFile_nbAnimation_Temp)
    {
    }
}