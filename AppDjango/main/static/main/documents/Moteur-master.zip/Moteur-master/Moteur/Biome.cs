namespace Moteur;

public abstract class Biome
{
    
}